#include "pch.h"
#include <iostream>
#include <cstdint>
#include "WECompress.h"
#include "afx.h"
//#include "afxwin.h"
#include "Structures.h"
//#include "afx.h"
#include "minwindef.h"
#include <afxwin.h>


CFilesStructList m_ImageFileList;
CFilesStructList m_PaletteFileList;
CString m_ImageFile = CString(" ");
CString m_PaletteFile = CString(" ");
CString m_SourceImageFile = CString(" ");
CString m_SourcePaletteFile = CString(" ");
UINT m_ActualImagesIndex = 0;
UINT m_ActualPalettesIndex = 0;
UINT m_ActualColorsNumber = 256;
UINT m_ComboPalIndex = -1; // INDICE DEL COMBO DE LA PALETA (4 bits - 8 bits)
UINT m_ComboIndex = -1; // INDICE DEL COMBO DE LA IMAGEN (BMP - TIM - RAW)
BOOL  m_AutomaticPal;


void InitTree(void)  // initialize trees 
{
    unsigned int i;

    for (i = 0; i < N + F; i++)
        ring_buff[i] = '\0';

    for (i = 0; i < N + 1 + HASHTAB; i++)
        next[i] = N;

    for (i = 0; i < N + 1; i++)
        prev[i] = N;
}

void InsertNode(unsigned int r)
{
    unsigned int next_r, c;

    c = ring_buff[r] + (ring_buff[r + 1] << 8) & 0xfff;// hash func
    next_r = next[c + N + 1];
    next[c + N + 1] = r;
    prev[r] = c + N + 1;
    next[r] = next_r;
    if (next_r != N)
        prev[next_r] = r;
}

void DeleteNode(unsigned int r)
{
    if (prev[r] == N)
        return;
    next[prev[r]] = next[r];
    prev[next[r]] = prev[r];
    prev[r] = next[r] = N;
}

void LocateNode(unsigned int r, unsigned int* match_len, unsigned int* match_pos)
{
    unsigned int p, c, i;

    *match_len = 0;
    *match_pos = 0;
    c = ring_buff[r] + (ring_buff[r + 1] << 8) & 0xfff;// hash func

    p = next[c + N + 1];
    i = 0;

    while (p != N)
    {
        for (i = 0; (i < F) && (ring_buff[p + i] == ring_buff[r + i]); i++);

        if (i > *match_len)
        {
            *match_len = i;
            *match_pos = (r - p) & (N - 1);
        };

        if (i == F)
            break;

        p = next[p];
    };

    if (i == F)
        DeleteNode(p);
}

int32_t FindCompressedLength(uint8_t* BufSrc)
{
    int32_t k3, counter;
    uint32_t i, j;
    uint8_t k, k2;

    i = 0;
    counter = 0;

    while (TRUE)
    {
        if ((i & 0x100) == 0)
        {
            k = *BufSrc & 0xFF;
            BufSrc++; // add pointer
            counter++; // counter
            i = k | 0xFF00;

        }

        if ((*BufSrc == 0) && (*(BufSrc + 1) == 0) && (*(BufSrc + 2) == 0) && (*(BufSrc + 3) == 0))
            return 0;// exit invalid compressed block

        k2 = *BufSrc & 0xFF; // get data			

        if (((uint8_t)i & 1) == 0)
        {
            BufSrc++;
            counter++; // counter
        }
        else
        {
            if ((k2 & 0x80) != 0)
            {
                BufSrc++;// add pointer
                counter++; // counter

                if ((k2 & 0x40) != 0)
                {
                    k = k2 & 0xFF;
                    k3 = k - 0xB9;
                    if (k == 0xFF)
                        break; // esci

                    while (k3-- >= 0)
                    {
                        k2 = *BufSrc & 0xFF;// get data
                        BufSrc++;// add pointer
                        counter++; // counter

                    }

                    i = i >> 1;// i SHR 1
                    continue;
                }

            }
            else
            {
                j = *(BufSrc + 1) & 0xFF;// get data (prendi il byte successivo)
                BufSrc = BufSrc + 2;// add pointer by 2
                counter += 2; // counter
            }

        }

        i = i >> 1;

    }

    return counter;

}

bool Compress(uint8_t** BufDest, uint8_t* BufSrc, uint32_t* SizeResult, uint32_t SizeSrc)
{
    uint8_t* ptrRes = *BufDest;
    unsigned int r, match_pos, match_len, maxlen, code_buf_ptr;
    uint32_t ps = 0, textsize, codesize;
    uint8_t  code_buf[17], mask, c;
    unsigned int block;

    InitTree();  // initialize trees     

    r = 0;
    textsize = codesize = 0;
    code_buf[0] = 0;
    code_buf_ptr = 1;
    mask = 1;

    if (textsize + F < SizeSrc)
        block = F;
    else
        block = SizeSrc - textsize;

    memcpy(ring_buff, BufSrc, block);
    memcpy(ring_buff + N, BufSrc, block);
    maxlen = block;
    textsize += block;
    BufSrc += block;

    while (maxlen)
    {
        LocateNode(r, &match_len, &match_pos);
        if (match_len > maxlen) match_len = maxlen;//at the end of file often happens		
        if ((match_len < THRESHOLD - 1) || ((match_len < THRESHOLD) && (match_pos > 16)))
        {
            match_len = 1;  // Not long enough match.  Send one byte.
            code_buf[code_buf_ptr++] = ring_buff[r];  // Send uncoded. 
        }
        else
            if ((match_len > 2 - 1) && (match_len < 6) && (match_pos < 17)) {
                code_buf[0] |= mask;  // 'send one byte' flag 
                code_buf[code_buf_ptr++] = (uint8_t)
                    (((match_len + 7 - 1) << 4) | (match_pos - 1));

            }
        /*	else
            if ((match_pos == 1) && (match_len > 6)) {
                code_buf[0] |= mask;  // 'send one byte' flag
                code_buf[code_buf_ptr++] = (BYTE)
                    (match_len + 0xB9);
            }*/
            else
            {
                code_buf[0] |= mask;  // 'send one byte' flag 
                code_buf[code_buf_ptr++] = (uint8_t)
                    (((match_len - 2 - 1) << 2) | (match_pos >> 8));
                code_buf[code_buf_ptr++] = (uint8_t)
                    (match_pos & 0xFF);

            }
        if ((mask <<= 1) == 0)
        {  // Shift mask left one bit. 
            memcpy(ptrRes, code_buf, code_buf_ptr);// Send at most 8 units of code together 
            ptrRes += code_buf_ptr;

            codesize += code_buf_ptr;
            code_buf[0] = 0;
            code_buf_ptr = 1;
            mask = 1;
        }

        while (match_len--)
        {
            DeleteNode((r + F) & (N - 1));
            maxlen--;
            if (textsize < SizeSrc)
            {
                c = *BufSrc++;
                ring_buff[(r + F) & (N - 1)] = c;
                if (r + F >= N) ring_buff[r + F] = c;
                textsize++; maxlen++;
            };

            InsertNode(r);
            r = (r + 1) & (N - 1);
        };

    };

    if (code_buf_ptr > 1)
    {
        code_buf[0] |= mask;  // 'send one byte' flag 
        code_buf[code_buf_ptr++] = 0xFF;
        code_buf[code_buf_ptr++] = 0x00;
        memcpy(ptrRes, code_buf, code_buf_ptr);
        ptrRes += code_buf_ptr;
        codesize += code_buf_ptr;
    }
    else
    {
        *ptrRes = 0x01;
        *ptrRes = 0xFF;
        *ptrRes = 0x00;
        ptrRes += 3;
    }

    *SizeResult = codesize;

    return true;
}

BOOL WECompress(BYTE** BufDest, BYTE* BufSrc, ULONG* SizeResult, ULONG SizeSrc)
{
    BYTE* ptrRes = *BufDest;
    UINT r, match_pos, match_len, maxlen, code_buf_ptr;
    ULONG ps = 0, textsize, codesize;
    BYTE  code_buf[17], mask, c;
    UINT block;

    InitTree();  // initialize trees     

    r = 0;
    textsize = codesize = 0;
    code_buf[0] = 0;
    code_buf_ptr = 1;
    mask = 1;

    if (textsize + F < SizeSrc)
        block = F;
    else
        block = SizeSrc - textsize;

    memcpy(ring_buff, BufSrc, block);
    memcpy(ring_buff + N, BufSrc, block);
    maxlen = block;
    textsize += block;
    BufSrc += block;

    while (maxlen)
    {
        LocateNode(r, &match_len, &match_pos);
        if (match_len > maxlen) match_len = maxlen;//at the end of file often happens		
        if ((match_len < THRESHOLD - 1) || ((match_len < THRESHOLD) && (match_pos > 16)))
        {
            match_len = 1;  // Not long enough match.  Send one byte.
            code_buf[code_buf_ptr++] = ring_buff[r];  // Send uncoded. 
        }
        else
            if ((match_len > 2 - 1) && (match_len < 6) && (match_pos < 17)) {
                code_buf[0] |= mask;  // 'send one byte' flag 
                code_buf[code_buf_ptr++] = (BYTE)
                    (((match_len + 7 - 1) << 4) | (match_pos - 1));

            }
        /*	else
            if ((match_pos == 1) && (match_len > 6)) {
                code_buf[0] |= mask;  // 'send one byte' flag
                code_buf[code_buf_ptr++] = (BYTE)
                    (match_len + 0xB9);
            }*/
            else
            {
                code_buf[0] |= mask;  // 'send one byte' flag 
                code_buf[code_buf_ptr++] = (BYTE)
                    (((match_len - 2 - 1) << 2) | (match_pos >> 8));
                code_buf[code_buf_ptr++] = (BYTE)
                    (match_pos & 0xFF);

            }
        if ((mask <<= 1) == 0)
        {  // Shift mask left one bit. 
            memcpy(ptrRes, code_buf, code_buf_ptr);// Send at most 8 units of code together 
            ptrRes += code_buf_ptr;

            codesize += code_buf_ptr;
            code_buf[0] = 0;
            code_buf_ptr = 1;
            mask = 1;
        }

        while (match_len--)
        {
            DeleteNode((r + F) & (N - 1));
            maxlen--;
            if (textsize < SizeSrc)
            {
                c = *BufSrc++;
                ring_buff[(r + F) & (N - 1)] = c;
                if (r + F >= N) ring_buff[r + F] = c;
                textsize++; maxlen++;
            };

            InsertNode(r);
            r = (r + 1) & (N - 1);
        };

    };

    if (code_buf_ptr > 1)
    {
        code_buf[0] |= mask;  // 'send one byte' flag 
        code_buf[code_buf_ptr++] = 0xFF;
        code_buf[code_buf_ptr++] = 0x00;
        memcpy(ptrRes, code_buf, code_buf_ptr);
        ptrRes += code_buf_ptr;
        codesize += code_buf_ptr;
    }
    else
    {
        *ptrRes = 0x01;
        *ptrRes = 0xFF;
        *ptrRes = 0x00;
        ptrRes += 3;
    }

    *SizeResult = codesize;

    return TRUE;
}

bool  DeCompress(uint8_t** BufDest, uint8_t* BufSrc) {
       uint8_t* ptrRes = *BufDest;
    int32_t k3;
    uint32_t i = 0;
    uint8_t k, k2;
    uint32_t j;

    while (true) {
        if ((i & 0x100) == 0) {
            k = *BufSrc & 0xFF;
            BufSrc++;
            i = k | 0xFF00;
        }

        k2 = *BufSrc & 0xFF;

        if ((i & 1) == 0) {
            *ptrRes = k2;
            ptrRes++;
            BufSrc++;
        }
        else {
            if ((k2 & 0x80) != 0) {
                BufSrc++;

                if ((k2 & 0x40) != 0) {
                    k = k2 & 0xFF;
                    k3 = k - 0xB9;
                    if (k == 0xFF) {
                        break;
                    }

                    while (k3-- >= 0) {
                        k2 = *BufSrc & 0xFF;
                        BufSrc++;
                        ptrRes++;
                        *(ptrRes - 1) = k2;
                    }

                    i = i >> 1;
                    continue;
                }

                j = (k2 & 0x0F) + 1;
                k3 = (k2 >> 4) - 7;
            }
            else {
                j = *(BufSrc + 1) & 0xFF;
                BufSrc += 2;
                k3 = (k2 >> 2) + 2;
                j = j | ((k2 & 3) << 8);
            }

            for (; k3 >= 0; k3--) {
                *ptrRes = *(ptrRes - j) & 0xFF;
                ptrRes++;
            }
        }

        i = i >> 1;
    }

    return true;
}

uint32_t Decompress(uint8_t** BufDest, uint8_t* BufSrc) {
    uint8_t* ptrRes = *BufDest;
    uint8_t* initialPtrRes = ptrRes;  // Guardamos el puntero inicial para calcular la diferencia al final
    int32_t k3;
    uint32_t i = 0;
    uint8_t k, k2;
    uint32_t j;

    while (true) {
        if ((i & 0x100) == 0) {
            k = *BufSrc & 0xFF;
            BufSrc++;
            i = k | 0xFF00;
        }

        k2 = *BufSrc & 0xFF;

        if ((i & 1) == 0) {
            *ptrRes = k2;
            ptrRes++;
            BufSrc++;
        }
        else {
            if ((k2 & 0x80) != 0) {
                BufSrc++;

                if ((k2 & 0x40) != 0) {
                    k = k2 & 0xFF;
                    k3 = k - 0xB9;
                    if (k == 0xFF) {
                        break;
                    }

                    while (k3-- >= 0) {
                        k2 = *BufSrc & 0xFF;
                        BufSrc++;
                        *ptrRes = k2;
                        ptrRes++;
                    }

                    i = i >> 1;
                    continue;
                }

                j = (k2 & 0x0F) + 1;
                k3 = (k2 >> 4) - 7;
            }
            else {
                j = *(BufSrc + 1) & 0xFF;
                BufSrc += 2;
                k3 = (k2 >> 2) + 2;
                j = j | ((k2 & 3) << 8);
            }

            for (; k3 >= 0; k3--) {
                *ptrRes = *(ptrRes - j) & 0xFF;
                ptrRes++;
            }
        }

        i = i >> 1;
    }

    // Calculamos la cantidad de bytes descomprimidos
    return  (uint32_t)(ptrRes - initialPtrRes);
      
}


BOOL DecodeImage(BYTE* BufSrc, BYTE** BufDest, ULONG xsize, ULONG ysize,
	BYTE depth, BYTE ComprFlag)
{
	ULONG xtemp;
	UINT j;

	BYTE* pDest = *BufDest;

	j = 0;
	if (depth == 4)
	{
		// 4 bit
		xtemp = xsize / 2;
		if (ComprFlag == BI_RGB)
		{
			for (long y1 = ysize - 1; y1 >= 0; y1--)
			{
				for (unsigned long x1 = 0; x1 < xtemp; x1++)
				{
					pDest[j] = (BufSrc[(y1 * xtemp) + x1]) >> 4;
					pDest[j] |= ((BufSrc[(y1 * xtemp) + x1] << 4) & 0xF0);
					j++;
				}
			}
		}
		else
		{
			// BI_RLE4
			BOOL bEOB = FALSE;
			BYTE* pSrc = BufSrc;

			int code1, code2, i, k, hi = 0, abs_cou = 0, adj_cou = 0;

			BYTE* pTempData = new BYTE[xtemp * ysize];
			pDest = pTempData;

			BYTE* sta_ptr = pDest;
			for (i = 0; i < xtemp * ysize && !bEOB; i += 2)
			{
				code1 = *pSrc++;
				code2 = *pSrc++;

				if (abs_cou)
				{
					if (hi)
						*pDest++ |= (code1 >> 4);
					else
						*pDest = (code1 & 0xF0);
					abs_cou--;
					hi ^= 1;

					if (abs_cou)
					{
						if (hi)
							*pDest++ |= (code1 & 0x0F);
						else
							*pDest = (code1 << 4);
						abs_cou--;
						hi ^= 1;
					}

					if (abs_cou)
					{
						if (hi)
							*pDest++ |= (code2 >> 4);
						else
							*pDest = (code2 & 0xF0);
						abs_cou--;
						hi ^= 1;
					}

					if (abs_cou)
					{
						if (hi)
							*pDest++ |= (code2 & 0x0F);
						else
							*pDest = (code2 << 4);
						abs_cou--;
						hi ^= 1;
					}
					continue;

				}

				if (code1 == 0)  // RLE_COMMAND
				{
					switch (code2) // Escape
					{
					case 0:	// End of line escape EOL
						if (!adj_cou)  adj_cou = 3 - ((pDest - sta_ptr + 3) % 4);
						for (i = 0; i < adj_cou; i++) *pDest++ = 0;
						continue;
					case 1: // End of block escape EOB
						if (!adj_cou)  adj_cou = 3 - ((pDest - sta_ptr + 3) % 4);
						for (i = 0; i < adj_cou; i++) *pDest++ = 0;
						bEOB = TRUE;
						break;
					case 2: // Delta escape. RLE_DELTA								
						break;
					default: // Literal packet
						abs_cou = code2;
						break;
					}
					continue;
				}

				if (!bEOB) // Literal
				{
					for (k = 0; k < code1 / 2; k++)
					{
						if (hi)
						{
							*pDest++ |= (code2 >> 4);
							*pDest = (code2 & 0x0F);
						}
						else
							*pDest++ = code2;
					}

					if (code1 % 2)
					{
						if (hi)
							*pDest++ |= (code2 >> 4);
						else
							*pDest = (code2 & 0xF0);
						hi ^= 1;
					}

				}
			}

			pDest = *BufDest;
			for (long y1 = ysize - 1; y1 >= 0; y1--)
			{
				for (unsigned long x1 = 0; x1 < xtemp; x1++)
				{
					pDest[j] = (pTempData[(y1 * xtemp) + x1]) >> 4;
					pDest[j] |= ((pTempData[(y1 * xtemp) + x1] << 4) & 0xF0);
					j++;
				}
			}

			delete pTempData;

		}
	}
	else
	{
		// 8 bit

		xtemp = xsize;
		if (ComprFlag == BI_RGB)
		{
			for (long y1 = ysize - 1; y1 >= 0; y1--) {
				for (unsigned long x1 = 0; x1 < xtemp; x1++)
					pDest[j++] = BufSrc[(y1 * xtemp) + x1];
			}
		}
		else
		{
			// BI_RLE8
			BOOL bEOB = FALSE;
			BYTE* pSrc = BufSrc;

			int code1, code2, i, k, abs_cou = 0, adj_cou = 0;

			BYTE* pTempData = new BYTE[xtemp * ysize];
			pDest = pTempData;

			BYTE* sta_ptr = pDest;
			for (i = 0; i < xtemp * ysize && !bEOB; i += 2)
			{
				code1 = *pSrc++;
				code2 = *pSrc++;

				if (abs_cou)
				{
					*pDest++ = code1;
					abs_cou--;
					if (abs_cou)
					{
						*pDest++ = code2;
						abs_cou--;
					}
					continue;
				}

				if (code1 == 0)  // RLE_COMMAND
				{
					switch (code2) // Escape
					{
					case 0:	// End of line escape EOL
						if (!adj_cou)  adj_cou = 3 - ((pDest - sta_ptr + 3) % 4);
						for (i = 0; i < adj_cou; i++) *pDest++ = 0;
						continue;
					case 1: // End of block escape EOB
						if (!adj_cou)  adj_cou = 3 - ((pDest - sta_ptr + 3) % 4);
						for (i = 0; i < adj_cou; i++) *pDest++ = 0;
						bEOB = TRUE;
						break;
					case 2: // Delta escape. RLE_DELTA								
						break;
					default: // Literal packet
						abs_cou = code2;
						break;
					}
					continue;
				}

				if (!bEOB) // Literal
					for (k = 0; k < code1; k++)
						*pDest++ = code2;
			}

			pDest = *BufDest;
			for (long y1 = ysize - 1; y1 >= 0; y1--) {
				for (unsigned long x1 = 0; x1 < xtemp; x1++)
					pDest[j++] = pTempData[(y1 * xtemp) + x1];
			}

			delete pTempData;
		}
	}

	return TRUE;
}

BOOL CreateFiles()
{
	CFile   fImage, fPalette, NewFileImage, NewFileCLUT, NewFilePAL;
	CString TempMsg, mPalettePAL;
	CFileException e;
	UINT j, depth, totalheader, rgbsize, usedcol, comprflag;
	ULONG xsize, ysize, ImageOffset, ImageLength, nImageSize, nPaletteSize;
	BYTE rgbq[RGB_SIZE256];
	BYTE clut[RGB_SIZE256 / 2];
	BOOL Result;

	// open data file to write
	if (!NewFileImage.Open(m_ImageFile, CFile::modeCreate | CFile::modeReadWrite | CFile::typeBinary, &e))
	{
		AfxMessageBox(_T("Error writing ") + m_ImageFile);
		return FALSE;
	}

	Result = TRUE;
	mPalettePAL = m_PaletteFile;
	//mPalettePAL (".clu", ".pal");
	// open data file to write
	if (!NewFilePAL.Open(mPalettePAL, CFile::modeCreate | CFile::modeReadWrite | CFile::typeBinary, &e))
	{
		AfxMessageBox(_T("Error writing ") + mPalettePAL);
		return FALSE;
	}
	// open data file to write
	if (!NewFileCLUT.Open(m_PaletteFile, CFile::modeCreate | CFile::modeReadWrite | CFile::typeBinary, &e))
	{
		AfxMessageBox(_T("Error writing ") + m_PaletteFile);
		return FALSE;
	}

	if (!fImage.Open(m_SourceImageFile, CFile::modeRead | CFile::typeBinary, &e))
	{
		AfxMessageBox(_T("Error reading in source File ") + m_SourceImageFile);
		return FALSE;
	}

	nImageSize = fImage.GetLength();

	BYTE* ImageBuf = new BYTE[nImageSize];
	fImage.Read(ImageBuf, nImageSize);
	fImage.Close();

	if (!m_AutomaticPal)
	{
		if (!fPalette.Open(m_SourcePaletteFile, CFile::modeRead | CFile::typeBinary, &e))
		{
			AfxMessageBox(_T("Error reading in source File ") + m_SourcePaletteFile);
			return FALSE;
		}

		nPaletteSize = fPalette.GetLength();

	}
	else
		nPaletteSize = 1;

	BYTE* PaletteBuf = new BYTE[nPaletteSize];
	if (!m_AutomaticPal)
	{
		fPalette.Read(PaletteBuf, nPaletteSize);
		fPalette.Close();
	}

	BYTE* pImage = ImageBuf;
	BYTE* pPalette = PaletteBuf;

	// palette reading
	if (!m_AutomaticPal)
	{
		if (m_ComboPalIndex == 0)
		{
			if (nPaletteSize == 16 * 2)
			{
				depth = 4;
				usedcol = 16;
				totalheader = TOTAL_HEADER_SIZE16;
				rgbsize = RGB_SIZE16;
			}
			else
				if (nPaletteSize == 256 * 2)
				{
					depth = 8;
					usedcol = 256;
					totalheader = TOTAL_HEADER_SIZE256;
					rgbsize = RGB_SIZE256;
				}
				else
					return FALSE;


			memcpy(clut, pPalette, nPaletteSize);

			for (WORD col = 0; col < nPaletteSize; col += 4)
			{
				WORD* tempword = new WORD;
				memcpy(tempword, pPalette + (col / 2), 2);
				rgbq[col] = ((WORD)(*tempword >> 10)) << 3;
				rgbq[col + 1] = ((WORD)(*tempword >> 5) & 0x1f) << 3;
				rgbq[col + 2] = ((WORD)(*tempword) & 0x1f) << 3;
				rgbq[col + 3] = 0;

				delete tempword;
			}
		}
		else
		{
			if (nPaletteSize == 16 * 4)
			{
				depth = 4;
				usedcol = 16;
				totalheader = TOTAL_HEADER_SIZE16;
				rgbsize = RGB_SIZE16;
			}
			else
				if (nPaletteSize == 256 * 4)
				{
					depth = 8;
					usedcol = 256;
					totalheader = TOTAL_HEADER_SIZE256;
					rgbsize = RGB_SIZE256;
				}
				else
					return FALSE;

			memcpy(rgbq, pPalette, nPaletteSize);

			j = 0;
			for (UINT col = 0; col < nPaletteSize; col += 4)
			{
				WORD tempword = (((BYTE)rgbq[col + 2] >> 3 |
					((WORD)(rgbq[col + 1] >> 3) << 5)) |
					(((DWORD)(BYTE)(rgbq[col] >> 3)) << 10));
				clut[j++] = LOBYTE(tempword);
				clut[j++] = HIBYTE(tempword);

			}

		}


	}
	else
	{
		if (m_ComboIndex == 0)
		{
			BITMAPINFOHEADER bmih_read;

			memcpy(&bmih_read, pImage + BMFH_SIZE, sizeof(BITMAPINFOHEADER));
			depth = bmih_read.biBitCount;

			if (depth == 4)
			{
				totalheader = TOTAL_HEADER_SIZE16;
				rgbsize = RGB_SIZE16;
				usedcol = 16;
			}
			else
				if (depth == 8)
				{
					totalheader = TOTAL_HEADER_SIZE256;
					rgbsize = RGB_SIZE256;
					usedcol = 256;
				}
				else
					return FALSE;

			memcpy(rgbq, pImage + 54, rgbsize);

			j = 0;
			for (UINT col = 0; col < rgbsize; col += 4)
			{
				WORD tempword = (((BYTE)rgbq[col + 2] >> 3 |
					((WORD)(rgbq[col + 1] >> 3) << 5)) |
					(((DWORD)(BYTE)(rgbq[col] >> 3)) << 10));
				clut[j++] = LOBYTE(tempword);
				clut[j++] = HIBYTE(tempword);

			}


		}
		else
			if (m_ComboIndex == 1)
			{
				TIM_HEADER THead_read;

				memcpy(&THead_read, pImage, sizeof(TIM_HEADER));

				if (THead_read.type == TIM_4Bit)
				{
					depth = 4;
					usedcol = 16;
					totalheader = TOTAL_HEADER_SIZE16;
					rgbsize = RGB_SIZE16;
				}
				else
					if (THead_read.type == TIM_8Bit)
					{
						depth = 8;
						usedcol = 256;
						totalheader = TOTAL_HEADER_SIZE256;
						rgbsize = RGB_SIZE256;
					}
					else
						return FALSE;

				memcpy(clut, pImage + 20, usedcol * 2);
				for (WORD col = 0; col < rgbsize; col += 4)
				{
					WORD* tempword = new WORD;
					memcpy(tempword, pImage + 20 + (col / 2), 2);
					rgbq[col] = ((WORD)(*tempword >> 10)) << 3;
					rgbq[col + 1] = ((WORD)(*tempword >> 5) & 0x1f) << 3;
					rgbq[col + 2] = ((WORD)(*tempword) & 0x1f) << 3;
					rgbq[col + 3] = 0;

					delete tempword;
				}

			}
			else
				return FALSE;

	}

	// image reading
	if (m_ComboIndex == 0)
	{
		BITMAPINFOHEADER bmih_read;

		memcpy(&bmih_read, pImage + BMFH_SIZE, sizeof(BITMAPINFOHEADER));
		xsize = bmih_read.biWidth;
		ysize = bmih_read.biHeight;
		comprflag = bmih_read.biCompression;
		ImageOffset = totalheader;
		ImageLength = xsize * ysize;
		if (depth == 4)
			ImageLength = ImageLength / 2;

	}
	else
		if (m_ComboIndex == 1)
		{
			TIM_DATAINFO TData_read;

			memcpy(&TData_read, pImage + 20 + usedcol * 2, sizeof(TIM_DATAINFO));

			xsize = TData_read.xsize * 2;
			ysize = TData_read.ysize;
			ImageLength = xsize * ysize;
			ImageOffset = 32 + usedcol * 2;

		}
		else
		{
			xsize = 128;
			ysize = 128;
			ImageLength = xsize * ysize;
			if (depth == 4)
				ImageLength = ImageLength / 2;
			ImageOffset = 0;

		}

	// write CLUT (psx uses 15bit RGB)
	NewFileCLUT.Write(clut, rgbsize / 2);

	// write converted CLUT RGB table (psx uses 15bit RGB)
	NewFilePAL.Write(rgbq, rgbsize);

	BYTE* pImageData = new BYTE[ImageLength];
	if (m_ComboIndex == 0)
	{
		BYTE* pImageTemp = new BYTE[ImageLength];

		Result = DecodeImage(pImage + ImageOffset, &pImageTemp, xsize, ysize, depth, comprflag);

		Compress(&pImageData, pImageTemp, &ImageLength, ImageLength);

		delete pImageTemp;
	}
	else
		//if (m_ComboIndex == 1)
	{
		Compress(&pImageData, pImage + ImageOffset, &ImageLength, ImageLength);

	}

	// write Data block
	NewFileImage.Write(pImageData, ImageLength);

	delete ImageBuf;
	delete PaletteBuf;
	delete pImageData;

	NewFileImage.Close();
	NewFileCLUT.Close();
	NewFilePAL.Close();

	return Result;

}


//using BYTE = uint8_t;
//using BOOL = bool;
//using ULONG = uint32_t;
//using LONG = int32_t;
//using UINT = unsigned int;  // Definición de UINT