#ifndef WECOMPRESS_H
#define WECOMPRESS_H
#include <cstdint>


#ifdef WE_COMPRESS_EXPORTS
#define WE_COMPRESS_API __declspec(dllexport)
#else
#define WE_COMPRESS_API __declspec(dllimport)
#endif

#define HASHTAB  4096	// size of hash
#define N		 1024	// size of ring buffer 
#define F  		 34     // size of look ahead buffer
#define THRESHOLD 3 

CFilesStructList m_ImageFileList;
CFilesStructList m_PaletteFileList;
CString m_ImageFile;
CString m_PaletteFile;
CString m_SourceImageFile;
CString m_SourcePaletteFile;
UINT	m_ActualImagesIndex;
UINT	m_ActualPalettesIndex;
UINT	m_ActualColorsNumber;
BOOL	m_FirstOK;
BOOL	m_SecondOK;
BOOL	m_ThirdOK;
BOOL	m_FourthOK;
BOOL	m_AutomaticPal;

uint8_t ring_buff[N + F];
unsigned int next[N + 1 + HASHTAB], prev[N + 1]; /* reserve space for hash as sons */

extern "C" {
	WE_COMPRESS_API void InitTree(void);
}
extern "C" {
	WE_COMPRESS_API void InsertNode(unsigned int r);
}
extern "C" {
	WE_COMPRESS_API void DeleteNode(unsigned int r);
}
extern "C" {
	WE_COMPRESS_API void LocateNode(unsigned int r, unsigned int* match_len, unsigned int* match_pos);
}
extern "C" {
	WE_COMPRESS_API bool Compress(uint8_t** BufDest, uint8_t* BufSrc, uint32_t* SizeResult, uint32_t SizeSrc);
}

extern "C" {
	WE_COMPRESS_API BOOL WECompress(BYTE** BufDest, BYTE* BufSrc, ULONG* SizeResult, ULONG SizeSrc);
}

extern "C" {
	WE_COMPRESS_API bool DeCompress(uint8_t** BufDest, uint8_t* BufSrc);
}

extern "C" {
	WE_COMPRESS_API uint32_t Decompress(uint8_t** BufDest, uint8_t* BufSrc);
}

extern "C" {
	WE_COMPRESS_API int32_t FindCompressedLength(uint8_t* BufSrc);
}

extern "C" {
	WE_COMPRESS_API BOOL DecodeImage(BYTE* BufSrc, BYTE** BufDest, ULONG xsize, ULONG ysize,
		BYTE depth, BYTE ComprFlag);
}

extern "C" {
	WE_COMPRESS_API BOOL CreateFiles();
}



#endif // CWECOMPRESS_H
//using BYTE = uint8_t;
//using BOOL = bool;
//using ULONG = uint32_t;
//using LONG = int32_t;
//using UINT = unsigned int;  // Definici�n de UINT